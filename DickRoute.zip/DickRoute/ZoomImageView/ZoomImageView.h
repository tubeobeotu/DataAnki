//
//  ZoomImageView.h
//  ZoomImageView
//
//  Created by muukii on 2016/10/15.
//  Copyright © 2016 muukii. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZoomImageView.
FOUNDATION_EXPORT double ZoomImageViewVersionNumber;

//! Project version string for ZoomImageView.
FOUNDATION_EXPORT const unsigned char ZoomImageViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZoomImageView/PublicHeader.h>


