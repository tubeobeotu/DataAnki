//
//  BaseModel.swift
//  CardhopTNV
//
//  Created by Tu on 4/6/19.
//  Copyright © 2019 tunv. All rights reserved.
//

import Foundation

class BaseModel: NSObject {
    open var identifier: String = ""
    override init() {
        
    }
}
