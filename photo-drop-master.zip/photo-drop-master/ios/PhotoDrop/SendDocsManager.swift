//
//  SendDocsManager.swift
//  PhotoDrop
//
//  Created by tunv on 8/15/18.
//  Copyright © 2018 Couchbase. All rights reserved.
//

import Foundation
import AssetsLibrary
protocol SendDocsManagerDelegate{
    func didChangeName(name: String)
    func didChangePrice(price: String)
}
class SendDocsManager:NSObject {
    var delegate:SendDocsManagerDelegate?
    
    var stringPort = ""
    
    var replicator: CBLReplication!
    
    var svURL = ""
    
    var clientURL = ""
    
    var sharedAssets:[ALAsset]?
    
    var database: CBLDatabase?
    
    
    var name = ""
    var price = ""
    
    var lastDoc = "1"
    var isAddedObserver = false
    init(_ assets: [ALAsset]?, _ port: String) {
        self.sharedAssets = assets
        self.stringPort = port
    }
    convenience init(_ assets: [ALAsset]?, _ port: String, _ db: CBLDatabase) {
        self.init(assets, port)
        self.database = db
    }
    convenience init(_ assets: [ALAsset]?, _ port: String, _ db: CBLDatabase, _ svURL: String) {
        self.init(assets, port, db)
        self.svURL = svURL
    }
    convenience init(_ assets: [ALAsset]?, _ port: String, _ db: CBLDatabase, _ svURL: String, _ clientUrl: String){
        self.init(assets, port, db, svURL)
        self.clientURL = clientUrl
    }
    
    deinit {
        self.removeDB()
    }
    
    func removeDB(){
        if database != nil {
            do {
                try database!.delete()
            } catch let error as NSError {
                NSLog("Cannot delete the database with error : ", error.description)
            }
        }
    }
    
    // MARK: - Action
    func cancel(){
        if self.replicator != nil {
            self.replicator.stop()
            NotificationCenter.default.removeObserver(self,
                                                      name: NSNotification.Name.cblReplicationChange, object: self.replicator)
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
        }
    }
    
    // MARK: - Capture QR Code
    
    // MARK: - Replication
    func resolveConflicts(docId: String){
//        DBResolveConflictManagerment.checkConflicts(self.database, docId: docId)
    }
    func replicate() {
        if database == nil {
            return
        }
        if(clientURL == ""){
            clientURL = "http://tunvs-iMac.local:"
        }
        if let url = URL.init(string: "\(clientURL)"){
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            var docIds: [String] = []
            if let sharedAssets = sharedAssets{
                for asset in sharedAssets {
                    let representation = asset.defaultRepresentation()
                    let bufferSize = Int(representation?.size() ?? 0)
                    let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity:bufferSize)
                    let buffered = representation?.getBytes(buffer, fromOffset: 0,
                                                            length: Int(representation?.size() ?? 0), error: nil) ?? 0
                    let data = Data(bytesNoCopy: UnsafeMutablePointer<UInt8>(buffer), count: buffered, deallocator: .free)
                    //                    let portData = stringPort.data(using: .utf8)
                    //
                    let doc = database!.createDocument()
                    
                    let rev = doc.newRevision()
                    rev.setAttachmentNamed("photo", withContentType: "application/octet-stream",
                                           content: data)
                    if(svURL != ""){
                        let svURLData = svURL.data(using: .utf8)
                        rev.setAttachmentNamed("serverURL", withContentType: "text/plain",
                                               content:svURLData)
                    }
                    do {
                        try rev.save()
                        docIds.append(doc.documentID)
                    } catch let error as NSError {
                        NSLog("Cannot save document: %@", error)
                    }
                }
            }else{
                
                var doc:CBLDocument!
                if(lastDoc != "1"){
                   doc = database!.document(withID: lastDoc)
                }
                if(doc == nil){
                    doc = database!.createDocument()
                    lastDoc = doc!.documentID
                }
                let rev = doc!.newRevision()
                
                if(name != ""){
                    let nameData = name.data(using: .utf8)
                    rev.setAttachmentNamed("name", withContentType: "text/plain",
                                           content: nameData)
                }
                if(price != ""){
                    let priceData = price.data(using: .utf8)
                    rev.setAttachmentNamed("price", withContentType: "text/plain",
                                           content: priceData)
                }
                
                if(svURL != ""){
                    let svURLData = svURL.data(using: .utf8)
                    rev.setAttachmentNamed("serverURL", withContentType: "text/plain",
                                           content:svURLData)
                }
                do {
                    try rev.save()
//                    docIds.append(doc!.documentID)
                } catch let error as NSError {
                    NSLog("Cannot save document: %@", error)
                }
            }
        
            replicator = database!.createPushReplication(url)
            NotificationCenter.default.addObserver(forName: NSNotification.Name.cblReplicationChange,
                                                   object: replicator, queue: nil) { (notification) -> Void in
                                                    if self.replicator.lastError == nil {
                                                        let totalCount = self.replicator.changesCount
                                                        let completedCount = self.replicator.completedChangesCount
                                                        if completedCount > 0 && completedCount == totalCount {
//                                                            self.2()
                                                            UIApplication.shared.isNetworkActivityIndicatorVisible = false
                                                        }
                                                    } else {
//                                                        self.resolveConflicts()
                                                        UIApplication.shared.isNetworkActivityIndicatorVisible = false
                                                    }
            }
            replicator.start()
        }
        
    }
    
    func pullBD(url: String){
        if(isAddedObserver == false){
            isAddedObserver = true
            self.startObserveDatabaseChange()
            
//            let conflictsLiveQuery = database!.createAllDocumentsQuery().asLive()
//            conflictsLiveQuery.allDocsMode = .onlyConflicts
//            conflictsLiveQuery.addObserver(self, forKeyPath: "rows", options: .new, context: nil)
//            conflictsLiveQuery.start()
            
           
            
        }
        if let url = URL.init(string: url){
            let replicator = database!.createPullReplication(url)
            replicator.start()
        }
        
    }
    
    func startObserveDatabaseChange() {

            NotificationCenter.default.addObserver(forName: NSNotification.Name.cblDatabaseChange,
                                                   object: database, queue: nil) {
                                                    (notification) -> Void in
                                                    if let changes = notification.userInfo!["changes"] as? [CBLDatabaseChange] {
                                                        
                                                        for change in changes {
                                                            self.lastDoc = change.documentID
                                                            self.resolveConflicts(docId: change.documentID)
                                                            self.setupValue(change.documentID)
                                                        }
                                                    }
            }
        
        
    }
    
    func setupValue(_ docId: String) {
        if database == nil {
            return
        }
        self.lastDoc = docId
        if let doc = database!.existingDocument(withID: docId) {
            
            if let attachment = doc.currentRevision?.attachmentNamed("name") {
                if let nameData = attachment.content{
                    let name = String.init(data: nameData, encoding: .utf8)
                    if let delegate = self.delegate{
                        delegate.didChangeName(name: name ?? "")
                    }
                }
                
            }
            if let attachment = doc.currentRevision?.attachmentNamed("price") {
                if let priceData = attachment.content{
                    let price = String.init(data: priceData, encoding: .utf8)
                    if let delegate = self.delegate{
                        delegate.didChangePrice(price: price ?? "")
                    }
                }
            }
        }
    }
    
}
