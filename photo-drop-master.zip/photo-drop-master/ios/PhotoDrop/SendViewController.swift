//
//  SendViewController
//  PhotoDrop
//
//  Created by Pasin Suriyentrakorn on 11/16/14.
//  Copyright (c) 2014 Couchbase. All rights reserved.
//

import UIKit
import AssetsLibrary
import AVFoundation

class SendViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    @IBOutlet weak var previewView: UIView!

    @IBOutlet weak var statusLabel: UILabel!
    var stringPort = ""
    var previewLayer: AVCaptureVideoPreviewLayer!
    var session: AVCaptureSession!
    var replicator: CBLReplication!
    
    
    var sharedAssets:[ALAsset]?

    var sendManager: SendDocsManager!
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            sendManager = SendDocsManager(self.sharedAssets, stringPort, try DatabaseUtil.getEmptyDatabase("db"))
            sendManager.clientURL = stringPort
        } catch let error as NSError {
            AppDelegate.showMessage("Cannot get a database with error : \(error.code)",
                title: "Error")
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if  self.sendManager.database != nil {
                self.sendManager.replicate()
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Action

    @IBAction func cancelAction(_ sender: AnyObject) {
        self.navigationController?.dismiss(animated: true,
                                           completion: { () -> Void in
                                            self.sendManager.cancel()
        })
    }

}
