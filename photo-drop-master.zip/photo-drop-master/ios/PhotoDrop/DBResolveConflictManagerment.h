//
//  DBResolveConflictManagerment.h
//  PhotoDrop
//
//  Created by tunv on 8/16/18.
//  Copyright © 2018 Couchbase. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CouchbaseLite/CouchbaseLite.h>
#import <CouchbaseLiteListener/CBLListener.h>
@interface DBResolveConflictManagerment : NSObject
+ (void)checkConflicts:(CBLDatabase *)database docId:(NSString *)docId vc:(UIViewController *)vc;
@end
