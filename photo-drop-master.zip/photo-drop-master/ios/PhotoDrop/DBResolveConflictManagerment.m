//
//  DBResolveConflictManagerment.m
//  PhotoDrop
//
//  Created by tunv on 8/16/18.
//  Copyright © 2018 Couchbase. All rights reserved.
//

#import "DBResolveConflictManagerment.h"

@implementation DBResolveConflictManagerment
+ (void)checkConflicts:(CBLDatabase *)database docId:(NSString *)docId vc:(UIViewController *)vc{
    CBLDocument* doc = [database documentWithID: docId];
    NSError* error;
    NSArray* conflicts = [doc getConflictingRevisions: &error];
    
    if (conflicts.count > 1) {
        // There is more than one current revision, thus a conflict!
        CBLSavedRevision *rev1 = ((CBLSavedRevision*)conflicts[0]);
        NSString *name1 = [[NSString alloc] initWithData:[[rev1 attachmentNamed:@"name"] content] encoding:NSASCIIStringEncoding];
        
        CBLSavedRevision *rev2 = ((CBLSavedRevision*)conflicts[1]);
        NSString *name2 = [[NSString alloc] initWithData:[[rev2 attachmentNamed:@"name"] content] encoding:NSASCIIStringEncoding];
        
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Title"
                                     message:@"merge"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:name1
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        [self actionMerge:database docId:docId doc:doc conflicts:conflicts keepRevision:rev1];
                                    }];
        
        UIAlertAction* noButton = [UIAlertAction
                                   actionWithTitle:name2
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       
                                       [self actionMerge:database docId:docId doc:doc conflicts:conflicts keepRevision:rev2];
                                   }];
        
        [alert addAction:yesButton];
        [alert addAction:noButton];
        
        [vc presentViewController:alert animated:YES completion:nil];
        
    }
}
+ (void)actionMerge:(CBLDatabase *)database docId:(NSString *)docId doc:(CBLDocument *)doc conflicts:(NSArray *)conflicts keepRevision:(CBLSavedRevision *)keepRevision{
    [database inTransaction: ^BOOL{
        NSDictionary* mergedProps = [self mergeRevisions: conflicts];
        
        // Delete the conflicting revisions to get rid of the conflict:
//        CBLSavedRevision* current = doc.currentRevision;
        for (CBLSavedRevision* rev in conflicts) {
            NSLog(@"rev prop: %@ is deleted: %i", rev.properties, rev.isDeletion);
            CBLUnsavedRevision *newRev = [rev createRevision];
            if (rev == keepRevision) {
                // add the 3 revision
                newRev.userProperties = [NSMutableDictionary dictionaryWithDictionary:mergedProps];
            } else {
                // mark other conflicts as deleted
                newRev.isDeletion = YES;
            }
            
            NSError *error;
            if (![newRev saveAllowingConflict: &error]){
                NSLog(@"newRev save: &error: %@", error);
                return NO;
            }
        }
        return YES;
    }];
}
+ (NSDictionary*)mergeRevisions:(NSArray*)conflicts {
    // Note: the first revision in the conflicts array may not be a current revision:
    NSDictionary* userProperties = ((CBLSavedRevision*)conflicts[0]).properties;
    NSMutableDictionary* mergedDict = [NSMutableDictionary dictionaryWithDictionary:userProperties];
    for (CBLSavedRevision* rev in conflicts) {
        if (rev == conflicts[0])
            continue;
        for (NSString* key in rev.properties) {
            mergedDict[key] = [NSString stringWithFormat:@"%@ %@", mergedDict[key], rev.properties[key]];
        }
    }
    NSLog(@"final properties to merge: %@", mergedDict);
    return mergedDict;
}
@end
