//
//  ReceiveViewController.swift
//  PhotoDrop
//
//  Created by Pasin Suriyentrakorn on 11/22/14.
//  Copyright (c) 2014 Couchbase. All rights reserved.
//

import UIKit
import AssetsLibrary

class ReceiveViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, NetServiceBrowserDelegate, NetServiceDelegate {
    var stringPort = ""
    var isClient:Bool = true
    @IBOutlet weak var lbl_address: UILabel!
    let kRequiresAuthentication:Bool = false
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var tf_clientURL: UITextField!
    
    @IBOutlet weak var tf_name: UITextField!
    
    @IBOutlet weak var tf_price: UITextField!
    
    
    var listener: CBLListener!
    
    var library: ALAssetsLibrary!
    
    var assets:[ALAsset] = []
    
    var database: CBLDatabase?
    var database2: CBLDatabase?
    
    var pushReplicators = [CBLReplication]()
    
    var syncUrl: URL!
    
    //Bonjour
    var browser: NetServiceBrowser!
    var services = [NetService]()
    let domain = "local"
    let name = "_probonjore._tcp."
    var clients = [String]()
    func startSearch(){
        self.services.removeAll()
        self.browser = NetServiceBrowser()
        self.browser.delegate = self
        
//        self.browser.schedule(in: RunLoop.current, forMode: .defaultRunLoopMode)
        self.browser.searchForServices(ofType: self.name, inDomain: self.domain)
//        RunLoop.current.run()
    }
    
    
    
    func netService(_ sender: NetService, didNotPublish errorDict: [String : NSNumber]) {
        debugPrint(errorDict)
    }
    
    func netServiceBrowserWillSearch(_ browser: NetServiceBrowser) {
        print("starting search..")
    }
    
    func netServiceBrowserDidStopSearch(_ browser: NetServiceBrowser) {
        print("Stoped search")
    }
    
    func netServiceBrowser(_ browser: NetServiceBrowser, didNotSearch errorDict: [String : NSNumber]) {
        print("error in search")
        debugPrint(errorDict)
    }
    
    func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
        print("found service")
        if(service.name.contains("couchbase")){
            services.append(service)
            service.delegate = self
            service.resolve(withTimeout: 3)
        }
        debugPrint(service)
    }
    
    func netServiceBrowser(_ browser: NetServiceBrowser, didRemove service: NetService, moreComing: Bool) {
        if let ix = self.services.index(of:service) {
            self.services.remove(at:ix)
            print("removing a service")
        }
    }
    
    func netServiceDidResolveAddress(_ sender: NetService) {
        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
        guard let data = sender.addresses?.first else { return }
        data.withUnsafeBytes { (pointer:UnsafePointer<sockaddr>) -> Void in
            guard getnameinfo(pointer, socklen_t(data.count), &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 else {
                return
            }
        }
        let ipAddress = String(cString:hostname)
        clients.append("http://\(ipAddress):\(sender.port)/db")
    }
    
    
    //
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(isClient == false)
        {
            startSearch()
        }
        
        
        collectionView.isHidden = true;
        
        do {
            database = try DatabaseUtil.getEmptyDatabase("db")
        } catch let error as NSError {
            database = nil
            AppDelegate.showMessage("Cannot get a database with error : \(error.code)",
                title: "Error")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if database == nil {
            return;
        }
        
        if (!startListener()) {
            AppDelegate.showMessage("Cannot start listener", title: "Error")
            return;
        }
        
        if syncUrl != nil {
            print(syncUrl.absoluteString)
            imageView.image = UIImage.qrCodeImageForString(syncUrl.absoluteString,
                                                           size: imageView.frame.size)
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        stopListener()
        for service in self.services{
            service.stop()
        }
        if database != nil {
            do {
                try database!.delete()
            } catch let error as NSError {
                NSLog("Cannot delete the database with error : ", error.description)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) { }
    
    // MARK: - Action
    
    @IBAction func cancelAction(_ sender: AnyObject) {
        self.navigationController?.dismiss(animated: true,
                                           completion: { () -> Void in })
    }
    
    // MARK: - Listener
    
    func startListener() -> Bool {
        if listener != nil {
            return true
        }
        
        if database == nil {
            return false
        }
        
        listener = CBLListener(manager: CBLManager.sharedInstance(), port: 0)
        let date = Date()
        
        self.listener.setBonjourName("couchbase\(date.timeIntervalSince1970)", type: "_probonjore._tcp.")
        var username: String?
        var password: String?
        
        listener.requiresAuth = kRequiresAuthentication
        if listener.requiresAuth {
            username = secureGenerateKey(CharacterSet.urlUserAllowed) 
            password = secureGenerateKey(CharacterSet.urlPasswordAllowed)
            if username == nil || password == nil {
                return false
            }
            listener.setPasswords([username! : password!])
        }
        
        var success: Bool
        do {
            try listener.start()
            success = true
        } catch {
            success = false
        }
        
        guard let url =  listener.url else {
            listener = nil
            
            return false
        }
        
        if success {
            syncUrl = generateSyncUrl(url, username: username, password: password,
                                      db: database!.name)
            self.lbl_address.text = "url:\(syncUrl.absoluteString)"
            startObserveDatabaseChange()
            return true
        } else {
            listener = nil
            return false
        }
    }
    
    func stopListener() {
        if listener != nil {
            listener.stop()
            listener = nil
            stopObserveDatabaseChange()
        }
    }
    
    func setupNewReplicator(stringPort: String){
//        for clientUrl in self.clients{
//            if(clientUrl.contains("\(listener.port)") == false){
//                let manager = SendDocsManager(nil, stringPort, self.database!, syncUrl.absoluteString, clientUrl)
//                manager.name = self.tf_name.text ?? ""
//                manager.price = self.tf_price.text ?? ""
//                manager.replicate()
//            }
//            
//        }
        
        
    }
    
    func secureGenerateKey(_ allowedCharacters: CharacterSet) -> String? {
        var data = Data(count:32)
        let result = data.withUnsafeMutableBytes {
            SecRandomCopyBytes(kSecRandomDefault, data.count, $0)
        }
        if result == errSecSuccess {
            let key = data.base64EncodedString(
                options: NSData.Base64EncodingOptions.lineLength64Characters)
            return key.addingPercentEncoding(withAllowedCharacters: allowedCharacters)!
        } else {
            return nil
        }
    }
    
    func generateSyncUrl(_ base: URL, username: String?, password: String?, db: String) -> URL? {
        if let url = URL(string: db, relativeTo: base) {
            if var urlComp = URLComponents(string: url.absoluteString) {
                urlComp.user = username
                urlComp.password = password
                return urlComp.url
            }
        }
        return nil
    }
    
    // MARK: - ALAssetsLibrary
    
    func assetsLibrary() -> ALAssetsLibrary {
        if library == nil {
            library = ALAssetsLibrary()
        }
        return library
    }
    
    func saveImageFromDocument(_ docId: String) {
        if database == nil {
            return
        }
        DBResolveConflictManagerment.checkConflicts(self.database, docId: docId, vc: self)
        var isRequestFromServer = false
        if let doc = database!.existingDocument(withID: docId) {
            if let attachment = doc.currentRevision?.attachmentNamed("serverURL") {
                if let stringData = attachment.content{
                    if let stringPort = String.init(data: stringData, encoding: .utf8){
                        if(stringPort == syncUrl.absoluteString){
                            isRequestFromServer = true
                            return
                        }
                    }
                }
            }
            if let attachment = doc.currentRevision?.attachmentNamed("photo") {
                let library = assetsLibrary()
                library.writeImageData(toSavedPhotosAlbum: attachment.content!, metadata: nil, completionBlock: { (url, error) in
                    if url != nil {
                        
                        library.asset(for: url, resultBlock: { (asset) in
                            if asset != nil {
                                self.assets.insert(asset!, at: 0)
                            }
                            DispatchQueue.main.async(execute: {
                                self.collectionView.insertItems(
                                    at:[IndexPath(row: 0, section: 0) ] )
                            })
                            if (self.isClient == false && isRequestFromServer == false){
                                self.setupNewReplicator(stringPort: "")
                            }
                        }, failureBlock: { (error) in
                            
                        })
                    }
                })
            }
            else{
                if let attachment = doc.currentRevision?.attachmentNamed("name") {
                    if let nameData = attachment.content{
                        let name = String.init(data: nameData, encoding: .utf8)
                        DispatchQueue.main.async {
                            self.tf_name.text = name
                        }
                        
                    }
                    
                }
                if let attachment = doc.currentRevision?.attachmentNamed("price") {
                    if let priceData = attachment.content{
                        let price = String.init(data: priceData, encoding: .utf8)
                        DispatchQueue.main.async {
                            self.tf_price.text = price
                        }
                    }
                }
                if (self.isClient == false && isRequestFromServer == false){
                    self.setupNewReplicator(stringPort: "")
                }
            }
            
            
        }
    }
    
    // MARK: - Database Change
    
    func startObserveDatabaseChange() {
        NotificationCenter.default.addObserver(forName: NSNotification.Name.cblDatabaseChange,
                                               object: database, queue: nil) {
                                                (notification) -> Void in
                                                if let changes = notification.userInfo!["changes"] as? [CBLDatabaseChange] {
                                                    for change in changes {
                                                        DispatchQueue.main.async(execute: {
                                                            if self.collectionView.isHidden {
                                                                self.collectionView.isHidden = false
                                                            }
                                                            
                                                            self.saveImageFromDocument(change.documentID)
                                                            
                                                            
                                                        })
                                                    }
                                                }
        }
    }
    
    func stopObserveDatabaseChange() {
        NotificationCenter.default.removeObserver(self,
                                                  name: NSNotification.Name.cblDatabaseChange, object: database)
    }
    
    // MARK: - UICollectionView
    
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        return self.assets.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "photoCell",
                                                      for: indexPath) as! PhotoViewCell
        let asset = assets[indexPath.row]
        cell.imageView.image = UIImage(cgImage: asset.thumbnail().takeUnretainedValue())
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAtIndexPath indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.size.width
        let size = (width - 6) / 3.0
        return CGSize(width: size, height: size)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 3.0
    }
}
