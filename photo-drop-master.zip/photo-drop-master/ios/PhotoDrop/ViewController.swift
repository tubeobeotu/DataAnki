//
//  ViewController.swift
//  PhotoDrop
//
//  Created by Pasin Suriyentrakorn on 11/14/14.
//  Copyright (c) 2014 Couchbase. All rights reserved.
//

import UIKit
import AssetsLibrary

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    @IBOutlet weak var tf_port: UITextField!
    @IBOutlet weak var btn_isClient: UIButton!
    
    @IBOutlet weak var collectionView: UICollectionView!

    @IBOutlet weak var tf_name: UITextField!
    @IBOutlet weak var tf_price: UITextField!
    var sendManager: SendDocsManager!
    var isClient:Bool = true {
        didSet{
            if(self.isClient == true){
                btn_isClient.setTitle("isClient", for: .normal)
            }else{
                btn_isClient.setTitle("isServer", for: .normal)
            }
        }
    }
    var library: ALAssetsLibrary!

    var assets:[ALAsset] = []

    var selectedAssets:[ALAsset] = []

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
             sendManager = SendDocsManager(nil, "", try DatabaseUtil.getEmptyDatabase("db"))
            sendManager.delegate = self
        } catch let error as NSError {
            AppDelegate.showMessage("Cannot get a database with error : \(error.code)",
                title: "Error")
        }
       
        
        tf_name.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        tf_price.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name.UIApplicationWillEnterForeground,
            object: nil, queue: nil) { (notification) -> Void in
                self.reloadAssets()
        }
    }
    
    
    
    
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        sendManager.clientURL = self.tf_port.text ?? ""
        sendManager.name = self.tf_name.text ?? ""
        sendManager.price = self.tf_price.text ?? ""
        sendManager.replicate()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        enableSendMode(false)
        reloadAssets()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated);
         self.sendManager.cancel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Navigation
    
    @IBAction func showReceiveVC(_ sender: Any) {

    }
    @IBAction func isClient(_ sender: Any) {
        isClient = !isClient
    }
    
    @IBAction func pullDB(_ sender: Any) {
        sendManager.pullBD(url: self.tf_port.text ?? "")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "send" {
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! SendViewController
            controller.stringPort = tf_port.text ?? ""
            controller.sharedAssets = selectedAssets
        }else{
            let navigationController = segue.destination as! UINavigationController
            let controller = navigationController.topViewController as! ReceiveViewController
            controller.stringPort = tf_port.text ?? ""
            controller.isClient = self.isClient
        }
    }

    // MARK: - Navigation Bar

    func enableSendMode(_ enabled: Bool) {
        if enabled {
            let sendButtonItem = UIBarButtonItem(title: "Send",
                style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.sendButtonAction(_:)))
            self.navigationItem.rightBarButtonItem = sendButtonItem
        } else {
            self.navigationItem.rightBarButtonItem = nil
        }
    }

    func sendButtonAction(_ sender: AnyObject) {
        self.performSegue(withIdentifier: "send", sender: self)
    }

    // MARK: - ALAssetsLibrary

    func reloadAssets() {
        if library == nil {
            library = ALAssetsLibrary()
        }

        assets = [];
        selectedAssets = [];

        library.enumerateGroups(withTypes: ALAssetsGroupType(ALAssetsGroupSavedPhotos), using: { (group, stop) in
            guard let group = group else {
                DispatchQueue.main.async(execute: {
                    self.collectionView.reloadData()
                })
                return
            }
           
            group.setAssetsFilter(ALAssetsFilter.allPhotos())
            group.enumerateAssets({ (asset, index, stop) in
                if asset != nil {
                    self.assets.append(asset!)
                }
            })
      
        }) { (error) in
            
        }
    }

    // MARK: - UICollectionView

    func collectionView(_ collectionView: UICollectionView,
        numberOfItemsInSection section: Int) -> Int {
        return self.assets.count
    }

    func collectionView(_ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "photoCell",
            for: indexPath) as! PhotoViewCell
        let asset = assets[indexPath.row]
        cell.imageView.image = UIImage(cgImage: asset.thumbnail().takeUnretainedValue())
        cell.checked = selectedAssets.contains(asset)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.size.width
        let size = (width - 6) / 3.0
        return CGSize(width: size, height: size)
    }

    func collectionView(_ collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 3.0
    }

    func collectionView(_ collectionView: UICollectionView,
        didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! PhotoViewCell
        let asset = assets[indexPath.row]
        if let foundIndex = selectedAssets.index(of: asset) {
            selectedAssets.remove(at: foundIndex)
            cell.checked = false
        } else {
            selectedAssets.append(asset)
            cell.checked = true
        }
        collectionView.reloadItems(at: [indexPath])

        self.enableSendMode(selectedAssets.count > 0)
    }
}
extension ViewController: SendDocsManagerDelegate {
    func didChangeName(name: String) {
        DispatchQueue.main.async {
            self.tf_name.text = name
        }
        
    }
    
    func didChangePrice(price: String) {
        DispatchQueue.main.async {
            self.tf_price.text = price
        }
    }
    
    
}
