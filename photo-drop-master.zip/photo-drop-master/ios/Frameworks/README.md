Put CouchbaseLite.framework and CouchbaseLiteListener.framework in this folder.
